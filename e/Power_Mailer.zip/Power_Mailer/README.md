# Power Mailer Inbox v2
Thanks For Use My SCRIPT Power Mailer Inbox v2  
Function Power Mailer Inbox v2 

1 - All Message Header Fields on 
2 - Name Message Fixed To <service> 
3 - Random Email Automaticly Change 

" Use it with a good server No #Blacklist "
Enjoy !
